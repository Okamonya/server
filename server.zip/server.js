const express = require('express')
const app = express();
const cors = require("cors");


// const corsOptions ={
//     origin:'http://localhost:3001', 
//     credentials:true,            //access-control-allow-credentials:true
//     methods: ["GET", "POST", "PUT", "DELETE"],
//     optionSuccessStatus:200
// }

app.use(cors())
app.use(express.json())

const register = require("./routes/register")
app.use("/add", register)

const login = require("./routes/login")
app.use("/auth", login)

const logged = require("./routes/logged")
app.use("/logged", logged)

const newEntry = require("./routes/newEmployee")
app.use("/newentry", newEntry)

const allEmployees = require("./routes/allEmployees")
app.use("/all-employees", allEmployees)

const addImage = require("./routes/addImage")
app.use("/add-image", addImage)

const getImages = require("./routes/getImages")
app.use("/get-image", getImages)

const update = require("./routes/update")
app.use("/update", update)

const expense = require("./routes/expense")
app.use("/expense", expense)

const allexpense = require("./routes/allexpenses")
app.use("/allexpenses", allexpense)

const search = require('./routes/search')
app.use('/search/:key', search)

const comexpenses = require('./routes/addCoExpense')
app.use('/add-expenses', comexpenses)

const getcomexpenses = require('./routes/getCoExpenses')
app.use('/get-expenses', getcomexpenses)

const deletecomexpenses = require('./routes/getCoExpenses')
app.use('/delete-expense/:idcomexpenses', deletecomexpenses)

app.listen(8001, () => {
    console.log('running on port 8001')
})